#Coded By M4rkWalker ... And Copyright Ofc xD 
#Youtube : M4rkWalker To Know Some Methods ABout Hacking/Cracking/Crading ....
#Sate !
#Sate !
#Sate !
import random 
import string
import  re, os,time,getpass,sys
from platform import system
from random import choice
######## Clear Terminal Or cmd ########
if os.name == 'nt':
	os.system('cls')
else:
	os.system('clear')
######## Work ########
def steam() :
 print("""  Steam Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 try :
   for az in range(int(zz)) :
    urname = string.ascii_letters + string.digits
    urname1 = ''.join(choice(urname) for _ in range(5))
    taki = string.ascii_letters + string.digits
    taki2 = ''.join(choice(taki) for _ in range(5))
    metsuha = string.ascii_letters + string.digits
    metsuha3 = ''.join(choice(metsuha) for _ in range(5)) 
    mark = urname1.upper() +('-')+ taki2.upper() +('-')+ metsuha3.upper()
    print(az+1,")",mark," by M4rk")
    save = open("steam.txt", 'a')
    save.write(mark + '\n')
   print("Continue ? [Y/N(yes/No)] ")
   so=input("> ")
   if so =='y' or so =='Y':
    main()
   else:
    exit()
 except : 
	   	 pass
def hma() :
 print("""  Hidemyass Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 try :
   for az in range(int(zz)) :
    urname = string.ascii_letters + string.digits
    urname1 = ''.join(choice(urname) for _ in range(6))
    taki = string.ascii_letters + string.digits
    taki2 = ''.join(choice(taki) for _ in range(6))
    metsuha = string.ascii_letters + string.digits
    metsuha3 = ''.join(choice(metsuha) for _ in range(6)) 
    mark = urname1.upper() +('-')+ taki2.upper() +('-')+ metsuha3.upper()
    print(az+1,")",mark," by M4rk")
    save = open("hma.txt", 'a')
    save.write(mark + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
 except : 
	   	 pass
def g2a() :
  print("""  G2A Generator (c)M4rkwalker """)
  zz=input('Enter Number Keys > ')
  try :
   for az in range(int(zz)) :
    urname = string.ascii_letters + string.digits
    urname1 = ''.join(choice(urname) for _ in range(4))
    taki = string.ascii_letters + string.digits
    taki2 = ''.join(choice(taki) for _ in range(4))
    metsuha = string.ascii_letters + string.digits
    metsuha3 = ''.join(choice(metsuha) for _ in range(4)) 
    mark = urname1.upper() +('-')+ taki2.upper() +('-')+ metsuha3.upper()
    print(az+1,")",mark," by M4rk")
    save = open("g2a.txt", 'a')
    save.write(mark + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
  except : 
	   	 pass
	   	
def gplay() :
 print("""  Googleplay Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 int(zz)
 try :
   for az in range(int(zz)) :
    urname = string.ascii_letters + string.digits
    urname1 = ''.join(choice(urname) for _ in range(4))
    taki = string.ascii_letters + string.digits
    taki2 = ''.join(choice(taki) for _ in range(4))
    metsuha = string.ascii_letters + string.digits
    metsuha3 = ''.join(choice(metsuha) for _ in range(4))
    miki = string.ascii_letters + string.digits
    miki3 = ''.join(choice(miki) for _ in range(4))
    tsukaza = string.ascii_letters + string.digits
    tsukaza3 = ''.join(choice(tsukaza) for _ in range(4))
    mark = urname1.upper() +('-')+ taki2.upper() +('-')+ metsuha3.upper() +('-')+ miki3.upper() +('-')+ tsukaza3.upper()
    print(az+1,")",mark," by M4rk")
    save = open("gplay.txt", 'a')
    save.write(mark + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
 except : 
	   	 pass
def express() :
 print("""  Express Vpn Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 try :
   for az in range(int(zz)) :
    urname = string.ascii_letters + string.digits
    urname1 = ''.join(choice(urname) for _ in range(22))
    print(az+1,")","E"+ urname1.upper()," by M4rk")
    save = open("express.txt", 'a')
    save.write(urname1 + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
 except : 
	   	 pass
def karta() :
 print("""  7ammass Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 try :
   for az in range(int(zz)) :
    gothar = string.digits
    gothar69 = ''.join(choice(gothar) for _ in range(14))
    print(az+1,")",gothar69," by M4rk")
    save = open("karta.txt", 'a')
    save.write(gothar69 + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
 except : 
	   	 pass
def Norton() :
 print("""  7ammass Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 try :
   for az in range(int(zz)) :
    gothar = string.ascii_letters + string.digits
    gothar69 = ''.join(choice(gothar) for _ in range(23))
    print(az+1,")",'V'+gothar69.upper()," by M4rk")
    save = open("norton.txt", 'a')
    save.write('V'+gothar69.upper() + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
 
 except : 
         pass
def avgantiv() :
 print("""  AVGAntivurus Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 try :
   for az in range(int(zz)) :
    meliodas = string.ascii_letters + string.digits
    meliodas1 = ''.join(choice(meliodas) for _ in range(4))
    ban = string.ascii_letters + string.digits
    ban1 = ''.join(choice(ban) for _ in range(5))
    king = string.ascii_letters + string.digits
    king1 = ''.join(choice(king) for _ in range(5))
    eskanor = string.ascii_letters + string.digits
    eskanor1 = ''.join(choice(eskanor) for _ in range(5))
    gothar = string.ascii_letters + string.digits
    gothar1 = ''.join(choice(gothar) for _ in range(2))
    nanatsu = '8MEH-R'+meliodas1.upper()+'-'+ban1.upper()+'-'+king1.upper()+'-'+eskanor1.upper()+'-'+gothar1.upper()+'MBR-ACED'
    print(az+1,")",nanatsu," by M4rk")
    save = open("avgantiv.txt", 'a')
    save.write(nanatsu + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
 except : 
         pass
def esetss() :
 print("""  ESet Smart Security Generator (c)M4rkwalker \n\n  1) Keyz\n  2) Accounts  """)
 psyco = input('$ ')
 if psyco == '1':
  zz=input('Enter Number Keys > ')
  try :
   for az in range(int(zz)) :
    meliodas = string.ascii_letters + string.digits
    meliodas1 = ''.join(choice(meliodas) for _ in range(5))
    ban = string.ascii_letters + string.digits
    ban1 = ''.join(choice(ban) for _ in range(5))
    king = string.ascii_letters + string.digits
    king1 = ''.join(choice(king) for _ in range(5))
    eskanor = string.ascii_letters + string.digits
    eskanor1 = ''.join(choice(eskanor) for _ in range(5))
    gothar = string.ascii_letters + string.digits
    gothar1 = ''.join(choice(gothar) for _ in range(5))
    nanatsu = meliodas1.upper()+'-'+ban1.upper()+'-'+eskanor1.upper()+'-'+king1.upper()+'-'+gothar1.upper()
    print(az+1,")",nanatsu," by M4rk")
    save = open("esetsskeys.txt", 'a')
    save.write(nanatsu + '\n')
   so=input("Continue ? [Y/N(yes/No)] > ")
   if so =='y' or so =='Y':
        main()
   else:
        exit()
  except : 
         pass
 elif psyco =='2':
  zz=input('Enter Number Accounts > ')
  try:
    for az in range(int(zz)) :
      nbadelelrapx99 = ''.join(choice(string.digits) for _ in range(10))
      mazelbekry = string.ascii_letters + string.digits
      mazelbekryx99 = ''.join(choice(string.digits) for _ in range(10))
      nhabettitle = 'UserNaMe : EVA-'+nbadelelrapx99+'\nPassword: '+mazelbekryx99.lower()+'\n-----------------------\nGenerated By M4rkWalker\n\n '
      print(az+1,")",nhabettitle)
      save = open("esetssup.txt", 'a')
      save.write(nhabettitle + '\n')
    so=input("Continue ? [Y/N(yes/No)] > ")
    if so =='y' or so =='Y':
        main()
    else:
        exit()
  except:
          pass
 else : 
    print("What U doing !! Bakka ")

def photoshop():
  print(""" PhotoShop Cs6 Genrator (c)M4rkwalker """)
  zz=input('Enter Number Keys > ')
  try:
    for az in range(int(zz)) :
        meliodas = string.digits
        meliodas1 = ''.join(choice(meliodas) for _ in range(5))
        ban = string.digits
        ban1 = ''.join(choice(ban) for _ in range(5))
        king = string.digits
        king1 = ''.join(choice(king) for _ in range(5))
        eskanor = string.ascii_letters + string.digits
        eskanor1 = ''.join(choice(eskanor) for _ in range(5))
        gothar = string.digits
        gothar1 = ''.join(choice(gothar) for _ in range(5))
        nanatsu= '1330'+'-'+meliodas1+'-'+ban1+'-'+king1+'-'+eskanor1+'-'+gothar1
        print(az+1,")",nanatsu,"\n------------By M4rkWalker---------------\n")
        save = open("cs6.txt", 'a')
        save.write(nanatsu + '\n')
    so=input("Continue ? [Y/N(yes/No)] > ")
    if so =='y' or so =='Y':
        main()
    else:
        exit()    
  except:
           pass
def winkeyz():
  print(""" WinDows Genrator (c)M4rkwalker """)
  zz=input('Enter Number Keys > ')
  try:
    for az in range(int(zz)) :
        meliodas = string.ascii_letters + string.digits
        meliodas1 = ''.join(choice(meliodas) for _ in range(5))
        ban = string.ascii_letters + string.digits
        ban1 = ''.join(choice(ban) for _ in range(5))
        king = string.ascii_letters + string.digits
        king1 = ''.join(choice(king) for _ in range(5))
        eskanor = string.ascii_letters + string.digits
        eskanor1 = ''.join(choice(eskanor) for _ in range(5))
        gothar = string.ascii_letters + string.digits
        gothar1 = ''.join(choice(gothar) for _ in range(5))
        nanatsu= meliodas1.upper()+'-'+ban1.upper()+'-'+king1.upper()+'-'+eskanor1.upper()+'-'+gothar1.upper()
        print(az+1,")",nanatsu,"\n------------By M4rkWalker---------------\n")
        save = open("win.txt", 'a')
        save.write(nanatsu + '\n')
    so=input("Continue ? [Y/N(yes/No)] > ")
    if so =='y' or so =='Y':
        main()
    else:
        exit() 
  except:
           pass 
def amazon():
 print("""  Amazon Generator (c)M4rkwalker """)
 zz=input('Enter Number Keys > ')
 try :
  for az in range(int(zz)) :
    urname = string.ascii_letters + string.digits
    urname1 = ''.join(choice(urname) for _ in range(4))
    taki = string.ascii_letters + string.digits
    taki2 = ''.join(choice(taki) for _ in range(6))
    metsuha = string.ascii_letters + string.digits
    metsuha3 = ''.join(choice(metsuha) for _ in range(5)) 
    mark = urname1.upper() +('-')+ taki2.upper() +('-')+ metsuha3.upper()
    print(az+1,")",mark," by M4rk")
    save = open("amazon.txt", 'a')
    save.write(mark + '\n')
  so=input("Continue ? [Y/N(yes/No)] > ")
  if so =='y' or so =='Y':
        main()
  else:
        exit()
 except : 
          pass

      
def abo():
 print("""
 Name : Zakarya
 Nickname : M4rkWalker
 Country : TN
 Facebook : [Not Avaible] / Maybe Im Here > Page : Fb.com/tnwix 
 Mail Me : Dream0@protonmail.com
 Github : https://github.com/m4rktn
 Youtube : M4rkWalker """)
 exit()
######## Menu ########
#Ps : Dont Change Logo 2 Say That u r The Coder ...Lean Python Its Free 
def main():
 logo = ("""                                     
                  `...`                 
              ,#@######@@+`             
            '##@@#@@@#@@@@#@.           
          .@@+#@@@@#@@@@@++@##          
         '@@@+++#@@@@#@#+++#@@@         
        +#@@@+++++#@@#+++++#@###        
       ,#@@@@+++++++#++++++#@#@#@       
       ##@@@@+++++'++#+++++@@#@@@+      
      +#@@@@@+++'+'::;#:+++##@@@##      
      @#@@@#@##++++++++####@#@##@@+     
     .@@@@@#+#++#+++++++++#++@@###@     
     +@@@++++++#++'##;++#'#++++#@#@     
     ##+++++++#+++#@##+++@+++++++##`    
     @#+++++++#+++@###+++@++++++'##`    
     ##@#'+++++#+++#@+++#+#+++'+@##`    
     ;#@@@#++#++#+++++++++#'+@###@@     
     `#@@@@@@##;#+''++'#;##@@@#####     
      @@@@@@@++++#+;;+#++++@#@@###,     
      ,#@@@@@+++++#''#+++++######@    #ZeroEye - Key Generator 
       ####@@+++++++#++++++######.    #(Updated in Aug2018) By M4rkWalker
        @@@@@++++++#@#+++++#@@##'     #Bug Fixed +New Keys+Control Th3Range
        `@@@@++++@@@@@@++++##@#'      #Without Checker | Check Manually
          #@@++@@@@@@@@@@++@@#;       #Mail Th3Coder : Dream0@protonmail.com
           :@@@@@@@@@@@#@@#@+`        
             ;#@@@@@@@@##@'.            
               `:'+##++;,               

 """)
 print(logo)
 print(' Hello '+getpass.getuser()+' : '+time.asctime( time.localtime(time.time()) ),'\n [!] Sometimes U Need To Use Vpn (Ban Or CountryNotAvaible)\n [1]  Steam ')
 print(" [2]  Express ")
 print(" [3]  Hidemyass ")
 print(" [4]  Tn Mobile Sold ")
 print(" [5]  G2A ")
 print(" [6]  Google Play ")
 print(" [7]  AVG Antivurus ")
 print(" [8]  Eset Smart Security ")
 print(" [9]  Norton Antivurus  ")
 print(" [10] PhotoShop Cs6  ")
 print(" [11] Win Keyz  ")
 print(" [12] Amaz0n  ")
 print(" [13] CCGen & CC'Check ")
 print(" [69] About & Exit ")

 zack = input("$ ")
 if zack == '1':
     steam()
 elif zack == '2':
    express()
 elif zack == '3' :
    hma()
 elif zack == '4' :
    karta()
 elif zack == '5' :
    g2a()
 elif zack == '6' :
    gplay()
 elif zack == '7' :
    avgantiv()
 elif zack == '8':
    esetss()
 elif zack == '9':
    Norton()
 elif zack == '10':
    photoshop()
 elif zack == '11':
    winkeyz()
 elif zack == '12':
    amazon()
 elif zack == '13':
    print("  Go To http://m4rkwalker.ga/cc.html Or Contact Me")
 elif zack == '69' :
    abo()
 else :
     print(" Open Ur Eye !! Bakka -____- ")
     exit()
if __name__ == '__main__':
	try:
		main()
	except KeyboardInterrupt:
		print (" \nNani ?? ... R U Bakka ??")
sys.exit()
######## Hey U r ... Do u Like Pizza ?? xD ########
